package br.fatec.HelpDesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpDeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
