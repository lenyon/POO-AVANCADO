package br.fatec.HelpDesk.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@NoArgsConstructor
@Data
@Entity
@Table (name = "Categoria", schema = "public" )
public class Categoria implements Serializable {
    @Serial
    public static final long serialVersionUID =123123124543534L;

    @Id
    @SequenceGenerator(
            name = "SEQ",
            sequenceName = "public.seq_Categoria",
            allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    private long id;
    @Column(name = "servico", nullable = false, length = 50)
    private String servico;

    public Categoria (String servico) {
        setServico(servico);
    }

    public void setCategoria(String nomeServico) {this.servico = nomeServico.toUpperCase();}


}
