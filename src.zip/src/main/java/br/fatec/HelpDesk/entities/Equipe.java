package br.fatec.HelpDesk.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@NoArgsConstructor
@Data
@Entity
@Table (name = "Equipe", schema = "public")
public class Equipe implements Serializable {
    @Serial
    public static final long serialVersionUID = 123123123123L;
    @Id
    @SequenceGenerator(
            name = "SEQ",
            sequenceName = "public.seq_equipe",
            allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    private long id;
    @Column(name = "equipe", nullable = false, length = 50)
    private String equipe;

    public Equipe(String equipe) {
        setEquipe(equipe);
    }
    public void setEquipe(String nomeEquipe) {
        this.equipe = nomeEquipe.toUpperCase();
    }

}
