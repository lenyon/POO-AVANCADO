package br.fatec.HelpDesk.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serial;
import java.io.Serializable;

@NoArgsConstructor
@Data
@Entity
@Table(name = "Perfil", schema = "public")
public class Perfil implements Serializable {
    @Serial
    public static final long serialVersionUID = -1293190823809103128L;
    @Id
    @SequenceGenerator(
            name = "SEQ",
            sequenceName = "public.seq_perfil",
            allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    private Long id;
    @Column(name = "perfil", nullable = false, length = 50)
    private String perfil;

    public Perfil(String perfil) {
        setPerfil(perfil);
    }

    public void setPerfil(String nomePerfil) {
        this.perfil = nomePerfil.toUpperCase();
    }
}
