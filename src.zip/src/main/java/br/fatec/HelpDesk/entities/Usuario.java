package br.fatec.HelpDesk.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@NoArgsConstructor
@Data
@Entity
@Table(name = "usuario", schema = "public")
public class Usuario implements Serializable {

    @Serial
    public static final long serialVersionUID = 14343452345L;

    @Id
    @SequenceGenerator(
            name = "SEQ",
            sequenceName = "public.seq_usuario",
            allocationSize = 1)
    @GeneratedValue (strategy = GenerationType.SEQUENCE, generator = "SEQ")
    private Long Id;

    @Column(name = "nome", nullable = false, length = 255)
    private String nome;

    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @Column(name = "senha", nullable = false, length = 255)
    private String senha;

    @Column(name = "cargo", length = 80)
    private String cargo;

    @Column(name = "telefone", length = 30)
    private String telefone;

    @OneToOne
    @JoinColumn(name = "id_perfil", referencedColumnName = "id",
            insertable = false, updatable = false)
    private Perfil perfil;
}
