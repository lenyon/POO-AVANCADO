package br.fatec.HelpDesk.services;

import br.fatec.HelpDesk.entities.Equipe;
import br.fatec.HelpDesk.repositories.EquipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EquipeService {

    @Autowired
    EquipeRepository equipeRepository;

    public Equipe cadastrar(String nomeEquipe) {
        return  equipeRepository.save(new Equipe(nomeEquipe));
    }

}
