package br.fatec.HelpDesk.services;

import br.fatec.HelpDesk.entities.Categoria;
import br.fatec.HelpDesk.repositories.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategoriaService {
    @Autowired
    CategoriaRepository categoriaRepository;

    public Categoria cadastrar(String nomeServico) {
        return categoriaRepository.save(new Categoria(nomeServico));
    }
}
