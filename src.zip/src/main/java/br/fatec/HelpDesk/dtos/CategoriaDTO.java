package br.fatec.HelpDesk.dtos;


import br.fatec.HelpDesk.entities.Categoria;

import java.io.Serial;
import java.io.Serializable;

public record CategoriaDTO(
        long id,
        String nomeServico
)implements Serializable {
    @Serial
    public static final long serialVersionUID = 123434534656677L;

    public static CategoriaDTO valueof(Categoria categoria) {
        if (categoria != null) {
            return new CategoriaDTO(
                    categoria.getId(),
                    categoria.getServico()
            );
        }
        return null;
    }

    public static Categoria toCategoria (CategoriaDTO categoriaDTO) {
        if (categoriaDTO != null) {
            Categoria categoria = new Categoria();
            categoria.setId(categoriaDTO.id);
            categoria.setServico(categoriaDTO.nomeServico);
        }
        return null;
    }

}
