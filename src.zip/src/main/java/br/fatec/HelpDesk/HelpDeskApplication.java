package br.fatec.HelpDesk;

import br.fatec.HelpDesk.entities.Perfil;
import br.fatec.HelpDesk.services.PerfilService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpDeskApplication {

	public static void main(String[] args) {

		SpringApplication.run(HelpDeskApplication.class, args);

//		PerfilService perfilService = new PerfilService();
//		Perfil perfil1 = perfilService.cadastrar("gerente");
//		Perfil perfil2 = perfilService.cadastrar("atendente");
//		Perfil perfil3 = perfilService.cadastrar("solicitante");
//
//		System.out.println("Perfil 1:"+ perfil1.getId() + " | " + perfil1.getPerfil());
//		System.out.println("Perfil 2:"+ perfil2.getId() + " | " + perfil2.getPerfil());
//		System.out.println("Perfil 3:"+ perfil3.getId() + " | " + perfil3.getPerfil());

	}
}
