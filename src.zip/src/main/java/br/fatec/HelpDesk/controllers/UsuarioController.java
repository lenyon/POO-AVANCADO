package br.fatec.HelpDesk.controllers;


import br.fatec.HelpDesk.dtos.UsuarioDTO;
import br.fatec.HelpDesk.entities.Usuario;
import br.fatec.HelpDesk.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
    @Autowired
    UsuarioService usuarioService;

    @PostMapping("/add")
    public @ResponseBody ResponseEntity<UsuarioDTO> cadastrar(@RequestPart UsuarioDTO dto){
        Usuario usuario = usuarioService.cadastrar(UsuarioDTO.toUsuario(dto));
        return ResponseEntity.ok().body(UsuarioDTO.valueof(usuario));
    }
}
